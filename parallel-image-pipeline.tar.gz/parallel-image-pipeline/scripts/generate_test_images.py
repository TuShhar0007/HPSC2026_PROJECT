#!/usr/bin/env python3
"""
generate_test_images.py
-----------------------
Generates synthetic PPM (P6) images for benchmarking the pipeline.
Images contain randomised noise + geometric shapes to give the filters
something meaningful to process.

Usage:
    python3 generate_test_images.py --out data/ --count 20 --width 512 --height 512
"""

import argparse
import os
import struct
import random
import math


def write_ppm(path: str, pixels: list[list[tuple[int, int, int]]]):
    """Write a list-of-rows of (R,G,B) tuples as a binary PPM P6 file."""
    H = len(pixels)
    W = len(pixels[0])
    with open(path, "wb") as f:
        f.write(f"P6\n{W} {H}\n255\n".encode())
        raw = bytearray(W * H * 3)
        idx = 0
        for row in pixels:
            for (r, g, b) in row:
                raw[idx]     = r
                raw[idx + 1] = g
                raw[idx + 2] = b
                idx += 3
        f.write(raw)


def generate_image(width: int, height: int, seed: int):
    """Return a 2-D list of (R,G,B) with random gradients, circles, and noise."""
    rng = random.Random(seed)

    # Base gradient
    pixels = []
    for y in range(height):
        row = []
        for x in range(width):
            r = int(255 * x / width)
            g = int(255 * y / height)
            b = int(255 * (1 - x / width))
            # Add random noise
            noise = rng.randint(-30, 30)
            row.append((
                max(0, min(255, r + noise)),
                max(0, min(255, g + noise)),
                max(0, min(255, b + noise)),
            ))
        pixels.append(row)

    # Draw random circles
    n_circles = rng.randint(3, 8)
    for _ in range(n_circles):
        cx = rng.randint(0, width  - 1)
        cy = rng.randint(0, height - 1)
        radius = rng.randint(20, min(width, height) // 4)
        cr = rng.randint(0, 255)
        cg = rng.randint(0, 255)
        cb = rng.randint(0, 255)

        y0 = max(0, cy - radius)
        y1 = min(height, cy + radius + 1)
        x0 = max(0, cx - radius)
        x1 = min(width,  cx + radius + 1)

        for y in range(y0, y1):
            for x in range(x0, x1):
                if (x - cx) ** 2 + (y - cy) ** 2 <= radius ** 2:
                    pixels[y][x] = (cr, cg, cb)

    return pixels


def main():
    parser = argparse.ArgumentParser(description="Generate synthetic PPM test images")
    parser.add_argument("--out",    default="data",  help="Output directory")
    parser.add_argument("--count",  type=int, default=20,  help="Number of images")
    parser.add_argument("--width",  type=int, default=512, help="Image width")
    parser.add_argument("--height", type=int, default=512, help="Image height")
    args = parser.parse_args()

    os.makedirs(args.out, exist_ok=True)

    for i in range(args.count):
        pixels = generate_image(args.width, args.height, seed=i * 31 + 7)
        path = os.path.join(args.out, f"image_{i:04d}.ppm")
        write_ppm(path, pixels)
        print(f"  [{i+1:3d}/{args.count}] {path}  ({args.width}×{args.height})")

    print(f"\nDone. {args.count} images written to '{args.out}/'")


if __name__ == "__main__":
    main()
