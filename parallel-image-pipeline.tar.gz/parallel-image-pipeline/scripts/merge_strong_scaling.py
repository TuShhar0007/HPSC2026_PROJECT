#!/usr/bin/env python3
"""
merge_strong_scaling.py
-----------------------
Merges multiple runs per thread count into a single timing_t<T>.csv
(mean of total pipeline time across runs) for the plot scripts.

Run after strong_scaling.sh completes:
    python3 scripts/merge_strong_scaling.py --results results/
"""

import argparse
import os
import glob
import re
import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", default="results/")
    args = parser.parse_args()

    # Find all thread counts
    pattern = os.path.join(args.results, "strong_t*_run*.csv")
    files   = sorted(glob.glob(pattern))

    thread_runs: dict[int, list[str]] = {}
    for path in files:
        m = re.search(r"strong_t(\d+)_run\d+\.csv", os.path.basename(path))
        if m:
            T = int(m.group(1))
            thread_runs.setdefault(T, []).append(path)

    if not thread_runs:
        print("No strong_t*_run*.csv files found. Nothing to merge.")
        return

    for T, paths in sorted(thread_runs.items()):
        arrays = []
        for path in paths:
            raw = np.genfromtxt(path, delimiter=",", names=True)
            if raw.ndim == 0:
                raw = raw.reshape(1)
            arrays.append(raw)

        # Average total time per stage across all runs and all images
        out_path = os.path.join(args.results, f"timing_t{T}.csv")
        with open(out_path, "w") as f:
            f.write("image_idx,t_io_load,t_gaussian,t_sobel,t_sharpen,t_histogram,t_total\n")
            # Use the first run's image count; sum across images per run then average
            n_img = len(arrays[0])
            for i in range(n_img):
                vals = {col: np.mean([a[col][i] for a in arrays if i < len(a)])
                        for col in ["t_io_load","t_gaussian","t_sobel",
                                    "t_sharpen","t_histogram","t_total"]}
                f.write(f"{i},{vals['t_io_load']:.6f},{vals['t_gaussian']:.6f},"
                        f"{vals['t_sobel']:.6f},{vals['t_sharpen']:.6f},"
                        f"{vals['t_histogram']:.6f},{vals['t_total']:.6f}\n")
        print(f"  Merged {len(paths)} runs → {out_path}")


if __name__ == "__main__":
    main()
