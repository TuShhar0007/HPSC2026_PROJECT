#!/usr/bin/env python3
"""
plot_weak_scaling.py
--------------------
Reads weak_t<T>.csv files and plots weak scaling efficiency:
    E_weak(T) = T_1 / T_T   (ideal = 1.0 / flat line)
"""

import argparse
import os
import glob
import re
import numpy as np
import matplotlib.pyplot as plt

plt.rcParams.update({"font.size": 12, "axes.grid": True, "grid.alpha": 0.35,
                     "figure.dpi": 150})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", default="results/")
    parser.add_argument("--out",     default="results/plots/")
    args = parser.parse_args()

    pattern = os.path.join(args.results, "weak_t*.csv")
    files   = sorted(glob.glob(pattern))

    if not files:
        print("No weak_t*.csv files found."); return

    data: dict[int, float] = {}
    for path in files:
        m = re.search(r"weak_t(\d+)\.csv", os.path.basename(path))
        if not m: continue
        T   = int(m.group(1))
        raw = np.genfromtxt(path, delimiter=",", names=True)
        if raw.ndim == 0: raw = raw.reshape(1)
        data[T] = float(np.sum(raw["t_total"]))

    threads = sorted(data.keys())
    T1      = data[threads[0]]
    eff     = [T1 / data[T] for T in threads]

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.plot(threads, eff, "bo-", linewidth=2, markersize=8, label="Observed")
    ax.axhline(1.0, color="k", linestyle="--", linewidth=1, alpha=0.5, label="Ideal")
    ax.set_xlabel("Thread count")
    ax.set_ylabel("Weak scaling efficiency  $T_1 / T_T$")
    ax.set_title("Weak Scaling Efficiency")
    ax.set_xticks(threads)
    ax.set_ylim(0, 1.2)
    ax.legend()
    fig.tight_layout()

    os.makedirs(args.out, exist_ok=True)
    path = os.path.join(args.out, "weak_scaling.png")
    fig.savefig(path, bbox_inches="tight")
    print(f"Saved: {path}")


if __name__ == "__main__":
    main()
