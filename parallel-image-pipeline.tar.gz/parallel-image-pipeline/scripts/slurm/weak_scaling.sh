#!/bin/bash
#SBATCH --job-name=me522_weak_scaling
#SBATCH --output=results/slurm_weak_%j.log
#SBATCH --error=results/slurm_weak_%j.err
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=32
#SBATCH --mem=128G
#SBATCH --time=04:00:00
#SBATCH --partition=compute

# ── IIT Mandi HPC Cluster – Weak Scaling Experiment ────────────────────
# Problem size grows proportionally with thread count:
#   T=1 → 500 images, T=2 → 1000 images, T=4 → 2000, ...
# Ideal weak-scaling efficiency = 1 (constant time per thread).

set -euo pipefail

echo "═══════════════════════════════════════════════════════════════"
echo "  ME 522 | Weak Scaling Benchmark"
echo "  Job ID: $SLURM_JOB_ID  |  Node: $SLURMD_NODENAME"
echo "  Date  : $(date)"
echo "═══════════════════════════════════════════════════════════════"

module load gcc/12.2.0
module load python/3.11

cd "$SLURM_SUBMIT_DIR"
make clean && make all
mkdir -p results data_weak

BASE_IMAGES=500

for T in 1 2 4 8 16 32; do
    N=$(( BASE_IMAGES * T ))
    echo ""
    echo "─── T=$T, N=$N images ─────────────────────────────────────"

    # Generate exact-N images for this run
    python3 scripts/generate_test_images.py \
        --out "data_weak/t${T}" \
        --count $N \
        --width 1024 --height 1024

    export OMP_NUM_THREADS=$T
    export OMP_PROC_BIND=close
    export OMP_PLACES=cores

    ./pipeline \
        -i "data_weak/t${T}" \
        -t $T \
        -b \
        -c "results/weak_t${T}.csv"

    rm -rf "data_weak/t${T}"   # free disk space immediately
done

echo ""
echo "Weak scaling complete."
python3 scripts/plot_weak_scaling.py --results results/ --out results/plots/
echo "Done."
