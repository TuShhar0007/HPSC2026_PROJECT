#!/bin/bash
#SBATCH --job-name=me522_strong_scaling
#SBATCH --output=results/slurm_strong_%j.log
#SBATCH --error=results/slurm_strong_%j.err
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=32
#SBATCH --mem=64G
#SBATCH --time=02:00:00
#SBATCH --partition=compute

# ── IIT Mandi HPC Cluster – Strong Scaling Experiment ──────────────────
# Runs the pipeline on a FIXED 500-image batch at 1,2,4,8,16,32 threads.
# Wall-clock times are recorded with omp_get_wtime() and written to CSV.

set -euo pipefail

echo "═══════════════════════════════════════════════════════════════"
echo "  ME 522 | Strong Scaling Benchmark"
echo "  Job ID: $SLURM_JOB_ID  |  Node: $SLURMD_NODENAME"
echo "  Date  : $(date)"
echo "═══════════════════════════════════════════════════════════════"

# Load required modules (adjust to your cluster's module names)
module load gcc/12.2.0
module load python/3.11

# Ensure binary is compiled
cd "$SLURM_SUBMIT_DIR"
make clean && make all

mkdir -p results data

# Generate test images if not already present
if [ ! -f data/image_0000.ppm ]; then
    echo "Generating 500 test images (2048×2048)..."
    python3 scripts/generate_test_images.py \
        --out data --count 500 --width 2048 --height 2048
fi

# Run for each thread count
for T in 1 2 4 8 16 32; do
    echo ""
    echo "─── Thread count: $T ─────────────────────────────────────"
    export OMP_NUM_THREADS=$T
    export OMP_PROC_BIND=close
    export OMP_PLACES=cores

    # Run 5 times and keep all; Python script takes mean/std
    for RUN in 1 2 3 4 5; do
        ./pipeline \
            -i data \
            -t $T \
            -b \
            -c "results/strong_t${T}_run${RUN}.csv"
    done
done

echo ""
echo "Strong scaling complete. Merging CSVs..."
python3 scripts/merge_strong_scaling.py --results results/
echo "Generating plots..."
python3 python/plot_scaling.py --results results/ --out results/plots/
echo "Done. Plots in results/plots/"
