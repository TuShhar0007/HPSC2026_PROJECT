#ifndef FILTERS_H
#define FILTERS_H

#include "image_io.h"

/*
 * All filter functions take a const Image* as input and return a newly
 * allocated Image*.  The caller owns the returned image and must call
 * image_free() on it.
 *
 * All inner pixel loops are parallelised with OpenMP.
 */

/* Stage 2 – Gaussian blur (separable 5×5, σ≈1.0) */
Image *filter_gaussian_blur(const Image *src);

/* Stage 3 – Sobel edge detection (grayscale output) */
Image *filter_sobel(const Image *src);

/* Stage 4 – Unsharp mask sharpening */
Image *filter_sharpen(const Image *src, float strength);

/* Helper: clamp a float to [0, 1] */
static inline float clampf(float v) {
    return v < 0.0f ? 0.0f : (v > 1.0f ? 1.0f : v);
}

#endif /* FILTERS_H */
