#include "image_io.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <dirent.h>
#include <omp.h>

/* ── Allocation / free ─────────────────────────────────────────────────── */

Image *image_alloc(int width, int height, int channels) {
    Image *img = (Image *)malloc(sizeof(Image));
    if (!img) return NULL;
    img->width    = width;
    img->height   = height;
    img->channels = channels;
    img->data     = (float *)calloc((size_t)width * height * channels, sizeof(float));
    if (!img->data) { free(img); return NULL; }
    return img;
}

void image_free(Image *img) {
    if (!img) return;
    free(img->data);
    free(img);
}

Image *image_clone(const Image *src) {
    if (!src) return NULL;
    Image *dst = image_alloc(src->width, src->height, src->channels);
    if (!dst) return NULL;
    size_t n = (size_t)src->width * src->height * src->channels;
    memcpy(dst->data, src->data, n * sizeof(float));
    return dst;
}

/* ── PPM I/O ───────────────────────────────────────────────────────────── */

static void skip_comments(FILE *f) {
    int c;
    while ((c = fgetc(f)) == '#') {
        while ((c = fgetc(f)) != '\n' && c != EOF);
    }
    ungetc(c, f);
}

Image *image_load_ppm(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) { perror(path); return NULL; }

    char magic[3];
    if (fscanf(f, "%2s", magic) != 1 || strcmp(magic, "P6") != 0) {
        fprintf(stderr, "image_load_ppm: %s is not a binary PPM (P6)\n", path);
        fclose(f); return NULL;
    }

    skip_comments(f);
    int width, height, maxval;
    if (fscanf(f, " %d %d %d ", &width, &height, &maxval) != 3) {
        fprintf(stderr, "image_load_ppm: bad header in %s\n", path);
        fclose(f); return NULL;
    }

    Image *img = image_alloc(width, height, 3);
    if (!img) { fclose(f); return NULL; }

    uint8_t *raw = (uint8_t *)malloc((size_t)width * height * 3);
    if (!raw) { image_free(img); fclose(f); return NULL; }

    size_t n_read = fread(raw, 1, (size_t)width * height * 3, f);
    fclose(f);

    if (n_read != (size_t)width * height * 3) {
        fprintf(stderr, "image_load_ppm: short read in %s\n", path);
        free(raw); image_free(img); return NULL;
    }

    float scale = 1.0f / (float)maxval;
    size_t total = (size_t)width * height * 3;

    #pragma omp parallel for schedule(static)
    for (size_t i = 0; i < total; i++)
        img->data[i] = raw[i] * scale;

    free(raw);
    return img;
}

int image_save_ppm(const Image *img, const char *path) {
    if (!img || img->channels < 3) return -1;
    FILE *f = fopen(path, "wb");
    if (!f) { perror(path); return -1; }

    fprintf(f, "P6\n%d %d\n255\n", img->width, img->height);

    size_t total = (size_t)img->width * img->height * 3;
    uint8_t *raw = (uint8_t *)malloc(total);
    if (!raw) { fclose(f); return -1; }

    #pragma omp parallel for schedule(static)
    for (size_t i = 0; i < total; i++) {
        float v = img->data[i];
        if (v < 0.0f) v = 0.0f;
        if (v > 1.0f) v = 1.0f;
        raw[i] = (uint8_t)(v * 255.0f + 0.5f);
    }

    fwrite(raw, 1, total, f);
    free(raw);
    fclose(f);
    return 0;
}

/* ── Batch I/O ─────────────────────────────────────────────────────────── */

Image **image_load_batch(const char *dir, int *count) {
    *count = 0;

    /* First pass: collect .ppm filenames */
    DIR *d = opendir(dir);
    if (!d) { perror(dir); return NULL; }

    int capacity = 64;
    char **paths = (char **)malloc(capacity * sizeof(char *));
    int n = 0;
    struct dirent *entry;

    while ((entry = readdir(d))) {
        const char *name = entry->d_name;
        size_t len = strlen(name);
        if (len > 4 && strcmp(name + len - 4, ".ppm") == 0) {
            if (n == capacity) {
                capacity *= 2;
                paths = (char **)realloc(paths, capacity * sizeof(char *));
            }
            size_t plen = strlen(dir) + 1 + len + 1;
            paths[n] = (char *)malloc(plen);
            snprintf(paths[n], plen, "%s/%s", dir, name);
            n++;
        }
    }
    closedir(d);

    if (n == 0) { free(paths); return NULL; }

    Image **batch = (Image **)malloc(n * sizeof(Image *));

    /* Parallel load across images */
    #pragma omp parallel for schedule(dynamic)
    for (int i = 0; i < n; i++) {
        batch[i] = image_load_ppm(paths[i]);
        free(paths[i]);
    }
    free(paths);

    *count = n;
    return batch;
}

void image_free_batch(Image **batch, int count) {
    if (!batch) return;
    for (int i = 0; i < count; i++) image_free(batch[i]);
    free(batch);
}

/* ── Grayscale conversion ──────────────────────────────────────────────── */

Image *image_to_gray(const Image *src) {
    if (!src) return NULL;
    Image *dst = image_alloc(src->width, src->height, 1);
    if (!dst) return NULL;
    int npix = src->width * src->height;

    if (src->channels == 1) {
        memcpy(dst->data, src->data, (size_t)npix * sizeof(float));
    } else {
        #pragma omp parallel for schedule(static)
        for (int i = 0; i < npix; i++) {
            float r = src->data[i * 3 + 0];
            float g = src->data[i * 3 + 1];
            float b = src->data[i * 3 + 2];
            /* ITU-R BT.601 luminance */
            dst->data[i] = 0.299f * r + 0.587f * g + 0.114f * b;
        }
    }
    return dst;
}
