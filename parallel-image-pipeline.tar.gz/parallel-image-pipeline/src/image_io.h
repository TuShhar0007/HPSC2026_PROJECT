#ifndef IMAGE_IO_H
#define IMAGE_IO_H

#include <stdint.h>
#include <stdlib.h>

/* ─── Image struct ──────────────────────────────────────────────────────── */
typedef struct {
    int    width;
    int    height;
    int    channels;   /* 1 = grayscale, 3 = RGB */
    float *data;       /* row-major, [h][w][c], values in [0, 1] */
} Image;

/* ─── Lifecycle ─────────────────────────────────────────────────────────── */
Image *image_alloc(int width, int height, int channels);
void   image_free(Image *img);
Image *image_clone(const Image *src);

/* ─── PPM I/O ───────────────────────────────────────────────────────────── */
Image *image_load_ppm(const char *path);
int    image_save_ppm(const Image *img, const char *path);

/* ─── Batch I/O ─────────────────────────────────────────────────────────── */
/* Reads all .ppm files in `dir` into a malloc'd array of Image*.
   Sets *count to the number loaded. Returns NULL on failure. */
Image **image_load_batch(const char *dir, int *count);
void    image_free_batch(Image **batch, int count);

/* ─── Utilities ─────────────────────────────────────────────────────────── */
/* Convert RGB to single-channel luminance (in-place modifies to channels=1) */
Image *image_to_gray(const Image *src);

#endif /* IMAGE_IO_H */
