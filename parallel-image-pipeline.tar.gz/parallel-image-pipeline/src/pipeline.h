#ifndef PIPELINE_H
#define PIPELINE_H

#include "image_io.h"

/*
 * PipelineResult holds one image through all five pipeline stages.
 * Intermediate images are retained so the caller can save or inspect them.
 */
typedef struct {
    Image *input;           /* Stage 0 – raw loaded image (RGB)   */
    Image *blurred;         /* Stage 2 – Gaussian blur             */
    Image *edges;           /* Stage 3 – Sobel edge magnitude      */
    Image *sharpened;       /* Stage 4 – Unsharp mask              */
    Image *equalized;       /* Stage 5 – Histogram equalised gray  */
} PipelineResult;

/*
 * PipelineTiming records wall-clock time (seconds) for each stage.
 * Each field includes omp_get_wtime() start/stop overhead only for that
 * stage — I/O is measured separately in stage_io_load.
 */
typedef struct {
    double t_io_load;       /* Stage 1 – image load + normalise    */
    double t_gaussian;      /* Stage 2 – Gaussian blur             */
    double t_sobel;         /* Stage 3 – Sobel edge detection      */
    double t_sharpen;       /* Stage 4 – Unsharp mask              */
    double t_histogram;     /* Stage 5 – Histogram equalisation    */
    double t_total;         /* Wall time for entire pipeline       */
} PipelineTiming;

/*
 * Run the full five-stage pipeline on a single image.
 * Returns a heap-allocated PipelineResult; caller owns it.
 * If timing != NULL, timings are recorded.
 *
 * sharpness: suggested range 0.5 – 1.5 (use 1.0 as default)
 */
PipelineResult *pipeline_run(Image *img, float sharpness,
                              PipelineTiming *timing);

/* Free all images inside a PipelineResult (does NOT free the result struct) */
void pipeline_result_free(PipelineResult *res);

/*
 * Batch runner: processes every image in `batch` using `nthreads` OpenMP
 * threads at the image-batch level (outer parallelism), and records per-run
 * timings in the caller-provided `timings` array (length count).
 *
 * Results are written into the caller-provided `results` array (length count).
 */
void pipeline_run_batch(Image **batch, int count,
                        float sharpness, int nthreads,
                        PipelineResult **results,
                        PipelineTiming  *timings);

#endif /* PIPELINE_H */
