#include "pipeline.h"
#include "image_io.h"
#include "filters.h"
#include "histogram.h"

#include <stdlib.h>
#include <stdio.h>
#include <omp.h>

/* ══════════════════════════════════════════════════════════════════════════
 * pipeline_run – single image, full five-stage pipeline
 * ══════════════════════════════════════════════════════════════════════════ */

PipelineResult *pipeline_run(Image *img, float sharpness,
                              PipelineTiming *t) {
    PipelineResult *res = (PipelineResult *)calloc(1, sizeof(PipelineResult));
    if (!res) return NULL;

    double t0_total = omp_get_wtime();

    /* ── Stage 1: store input reference (already loaded) ──────────────── */
    double t0 = omp_get_wtime();
    res->input = img;   /* borrow; not freed by pipeline_result_free */
    double t1 = omp_get_wtime();
    if (t) t->t_io_load = t1 - t0;

    /* ── Stage 2: Gaussian blur ───────────────────────────────────────── */
    t0 = omp_get_wtime();
    res->blurred = filter_gaussian_blur(img);
    t1 = omp_get_wtime();
    if (t) t->t_gaussian = t1 - t0;

    /* ── Stage 3: Sobel edge detection ───────────────────────────────── */
    t0 = omp_get_wtime();
    res->edges = filter_sobel(res->blurred);   /* edge on smoothed image */
    t1 = omp_get_wtime();
    if (t) t->t_sobel = t1 - t0;

    /* ── Stage 4: Unsharp mask sharpening ────────────────────────────── */
    t0 = omp_get_wtime();
    res->sharpened = filter_sharpen(img, sharpness);
    t1 = omp_get_wtime();
    if (t) t->t_sharpen = t1 - t0;

    /* ── Stage 5: Histogram equalisation ─────────────────────────────── */
    t0 = omp_get_wtime();
    Image *gray = image_to_gray(img);
    res->equalized = histogram_equalize(gray);
    image_free(gray);
    t1 = omp_get_wtime();
    if (t) t->t_histogram = t1 - t0;

    if (t) t->t_total = omp_get_wtime() - t0_total;

    return res;
}

/* ══════════════════════════════════════════════════════════════════════════
 * pipeline_result_free
 * ══════════════════════════════════════════════════════════════════════════ */

void pipeline_result_free(PipelineResult *res) {
    if (!res) return;
    /* input is a borrowed pointer – do NOT free here */
    image_free(res->blurred);
    image_free(res->edges);
    image_free(res->sharpened);
    image_free(res->equalized);
}

/* ══════════════════════════════════════════════════════════════════════════
 * pipeline_run_batch – outer image-level parallelism
 * ══════════════════════════════════════════════════════════════════════════
 *
 * Each OpenMP thread claims a different image from the batch and runs the
 * full pipeline independently.  Because the pipeline stages themselves also
 * use OpenMP (inner parallelism), this uses nested parallelism.  Set
 * OMP_MAX_ACTIVE_LEVELS=2 in your environment or call
 *   omp_set_max_active_levels(2);
 * before this function if you want both levels active simultaneously.
 * For single-node benchmarks it is often better to disable nested
 * parallelism and rely only on the outer loop – controlled by `nthreads`.
 */
void pipeline_run_batch(Image **batch, int count,
                        float sharpness, int nthreads,
                        PipelineResult **results,
                        PipelineTiming  *timings) {
    omp_set_num_threads(nthreads);

    #pragma omp parallel for schedule(dynamic)
    for (int i = 0; i < count; i++) {
        PipelineTiming *tp = timings ? &timings[i] : NULL;
        results[i] = pipeline_run(batch[i], sharpness, tp);
    }
}
