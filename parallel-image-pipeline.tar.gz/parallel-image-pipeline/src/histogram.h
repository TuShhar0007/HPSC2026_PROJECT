#ifndef HISTOGRAM_H
#define HISTOGRAM_H

#include "image_io.h"

#define HIST_BINS 256

/*
 * Stage 5 – Histogram Equalization
 *
 * Operates on single-channel (grayscale) images.
 * Uses #pragma omp parallel for reduction(+:hist[...]) to safely
 * accumulate per-bin counts without explicit locks.
 *
 * Returns a newly allocated Image* that the caller must free.
 */
Image *histogram_equalize(const Image *src);

/*
 * Compute and return the raw histogram of a grayscale image.
 * hist must point to an int array of length HIST_BINS.
 */
void histogram_compute(const Image *src, long long hist[HIST_BINS]);

#endif /* HISTOGRAM_H */
