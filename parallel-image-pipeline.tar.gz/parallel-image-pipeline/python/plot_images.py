#!/usr/bin/env python3
"""
plot_images.py
--------------
Creates a side-by-side comparison figure showing all five pipeline stages
for a single sample image.

Input: a directory of PPM files named with the convention written by main.c:
    output/blur_0000.ppm, output/edges_0000.ppm, ...

Usage:
    python3 python/plot_images.py --input data/image_0000.ppm \
                                  --output_dir output/ \
                                  --idx 0 --out results/plots/stage_comparison.png
"""

import argparse
import os
import struct
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec


def read_ppm(path: str) -> np.ndarray:
    """Read a P6 PPM file, return float32 array [H, W, 3] in [0, 1]."""
    with open(path, "rb") as f:
        # Read header (skip comment lines)
        def next_token():
            tok = b""
            c = f.read(1)
            while c in (b" ", b"\t", b"\n", b"\r"):
                c = f.read(1)
            if c == b"#":
                while c != b"\n":
                    c = f.read(1)
                return next_token()
            while c not in (b" ", b"\t", b"\n", b"\r", b""):
                tok += c
                c = f.read(1)
            return tok.decode()

        magic  = next_token()
        if magic != "P6":
            raise ValueError(f"{path}: not a P6 PPM file (got '{magic}')")
        width  = int(next_token())
        height = int(next_token())
        maxval = int(next_token())

        raw = np.frombuffer(f.read(width * height * 3), dtype=np.uint8)
    img = raw.reshape(height, width, 3).astype(np.float32) / maxval
    return img


def read_ppm_gray(path: str) -> np.ndarray:
    """Load PPM and return grayscale 2-D array."""
    img = read_ppm(path)
    return 0.299 * img[:, :, 0] + 0.587 * img[:, :, 1] + 0.114 * img[:, :, 2]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input",      required=True,  help="Original input PPM path")
    parser.add_argument("--output_dir", default="output", help="Pipeline output directory")
    parser.add_argument("--idx",        type=int, default=0, help="Image index (0-padded to 4 digits)")
    parser.add_argument("--out",        default="results/plots/stage_comparison.png",
                        help="Output figure path")
    args = parser.parse_args()

    idx_str = f"{args.idx:04d}"
    stages  = {
        "Input (original)":     args.input,
        "Gaussian Blur":        os.path.join(args.output_dir, f"blur_{idx_str}.ppm"),
        "Sobel Edge Detection": os.path.join(args.output_dir, f"edges_{idx_str}.ppm"),
        "Unsharp Mask":         os.path.join(args.output_dir, f"sharp_{idx_str}.ppm"),
        "Histogram Equalized":  os.path.join(args.output_dir, f"eq_{idx_str}.ppm"),
    }

    fig, axes = plt.subplots(1, 5, figsize=(20, 4))
    fig.suptitle("Pipeline Stage Comparison – Image " + idx_str, fontsize=14)

    for ax, (title, path) in zip(axes, stages.items()):
        ax.set_title(title, fontsize=10)
        ax.axis("off")
        if not os.path.exists(path):
            ax.text(0.5, 0.5, "Not found", ha="center", va="center",
                    transform=ax.transAxes, color="red")
            continue
        try:
            img = read_ppm(path)
            if img.ndim == 3 and img.shape[2] == 1:
                img = img[:, :, 0]
            cmap = "gray" if img.ndim == 2 else None
            ax.imshow(img, cmap=cmap, vmin=0, vmax=1)
        except Exception as e:
            ax.text(0.5, 0.5, str(e), ha="center", va="center",
                    transform=ax.transAxes, color="red", fontsize=7)

    plt.tight_layout()
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    fig.savefig(args.out, dpi=150, bbox_inches="tight")
    print(f"Stage comparison saved to: {args.out}")


if __name__ == "__main__":
    main()
