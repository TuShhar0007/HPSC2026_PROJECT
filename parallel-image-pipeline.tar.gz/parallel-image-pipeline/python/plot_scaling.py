#!/usr/bin/env python3
"""
plot_scaling.py
---------------
Reads per-image timing CSVs produced by the pipeline benchmark (make bench)
and generates publication-quality scaling plots:

  1. Speedup vs thread count  (strong scaling, per stage + total)
  2. Parallel efficiency vs thread count
  3. Amdahl theoretical vs observed speedup overlay
  4. Weak scaling efficiency (if weak-scaling CSVs are present)

Expected CSV format (one per thread count T):
    timing_t<T>.csv  with columns:
    image_idx, t_io_load, t_gaussian, t_sobel, t_sharpen, t_histogram, t_total

Usage:
    python3 python/plot_scaling.py --results results/ --out results/plots/
"""

import argparse
import os
import glob
import re
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

plt.rcParams.update({
    "font.family":      "DejaVu Sans",
    "font.size":        12,
    "axes.titlesize":   13,
    "axes.labelsize":   12,
    "legend.fontsize":  10,
    "figure.dpi":       150,
    "axes.grid":        True,
    "grid.alpha":       0.35,
})

STAGES = ["t_gaussian", "t_sobel", "t_sharpen", "t_histogram", "t_total"]
STAGE_LABELS = {
    "t_gaussian":  "Gaussian Blur",
    "t_sobel":     "Sobel Edges",
    "t_sharpen":   "Unsharp Mask",
    "t_histogram": "Histogram Eq.",
    "t_total":     "Total Pipeline",
}
COLORS = plt.cm.tab10.colors


# ── Load CSVs ────────────────────────────────────────────────────────────

def load_timings(results_dir: str) -> dict[int, dict[str, float]]:
    """Return {thread_count: {stage: mean_wall_time_seconds}}"""
    pattern = os.path.join(results_dir, "timing_t*.csv")
    files   = sorted(glob.glob(pattern))
    data    = {}

    for path in files:
        m = re.search(r"timing_t(\d+)\.csv", os.path.basename(path))
        if not m:
            continue
        T = int(m.group(1))
        raw = np.genfromtxt(path, delimiter=",", names=True)
        if raw.ndim == 0:          # single-row file
            raw = raw.reshape(1)
        entry = {}
        for stage in STAGES:
            # Sum across images gives total wall-time for that stage across batch
            entry[stage] = float(np.sum(raw[stage]))
        data[T] = entry

    return data


# ── Amdahl's law ─────────────────────────────────────────────────────────

def amdahl(n, f_serial=0.045):
    """Theoretical speedup: S(n) = 1 / (f + (1-f)/n)"""
    return 1.0 / (f_serial + (1.0 - f_serial) / n)


# ── Plots ─────────────────────────────────────────────────────────────────

def plot_speedup(data: dict, out_dir: str):
    threads = sorted(data.keys())
    t1 = data[threads[0]]   # serial baseline

    fig, ax = plt.subplots(figsize=(8, 5))

    for idx, stage in enumerate(STAGES):
        speedups = [t1[stage] / data[T][stage] for T in threads]
        lw = 2.5 if stage == "t_total" else 1.5
        ls = "-" if stage == "t_total" else "--"
        ax.plot(threads, speedups, marker="o", linewidth=lw, linestyle=ls,
                color=COLORS[idx], label=STAGE_LABELS[stage])

    # Ideal linear speedup
    ax.plot(threads, threads, "k--", linewidth=1, alpha=0.4, label="Ideal linear")

    # Amdahl
    fine = np.linspace(threads[0], threads[-1], 200)
    ax.plot(fine, [amdahl(n) for n in fine], "k:", linewidth=1.5,
            alpha=0.6, label="Amdahl (f=4.5%)")

    ax.set_xlabel("Thread count")
    ax.set_ylabel("Speedup  $S = T_1 / T_n$")
    ax.set_title("Strong Scaling – Speedup vs Thread Count")
    ax.set_xticks(threads)
    ax.legend(loc="upper left")
    fig.tight_layout()
    path = os.path.join(out_dir, "speedup.png")
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}")


def plot_efficiency(data: dict, out_dir: str):
    threads = sorted(data.keys())
    t1 = data[threads[0]]

    fig, ax = plt.subplots(figsize=(8, 5))

    for idx, stage in enumerate(STAGES):
        effs = [t1[stage] / (data[T][stage] * T) for T in threads]
        ax.plot(threads, [e * 100 for e in effs], marker="s", linewidth=1.8,
                color=COLORS[idx], label=STAGE_LABELS[stage])

    ax.axhline(100, color="k", linestyle="--", linewidth=1, alpha=0.4, label="Ideal 100%")
    ax.axhline(70,  color="r", linestyle=":",  linewidth=1, alpha=0.5, label="70% threshold")
    ax.set_xlabel("Thread count")
    ax.set_ylabel("Parallel efficiency  $E = S / n$  (%)")
    ax.set_title("Strong Scaling – Parallel Efficiency")
    ax.set_xticks(threads)
    ax.set_ylim(0, 115)
    ax.legend(loc="upper right")
    fig.tight_layout()
    path = os.path.join(out_dir, "efficiency.png")
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}")


def plot_amdahl_overlay(data: dict, out_dir: str):
    threads = sorted(data.keys())
    t1 = data[threads[0]]
    obs = [t1["t_total"] / data[T]["t_total"] for T in threads]

    fig, ax = plt.subplots(figsize=(7, 5))
    fine = np.linspace(1, max(threads), 300)

    # Fit f_serial from observed data using last point
    # S_obs = 1 / (f + (1-f)/N)  => f = (1/S - 1/N) / (1 - 1/N)
    S_last = obs[-1]
    N_last = threads[-1]
    f_fit  = max(0.001, (1/S_last - 1/N_last) / (1 - 1/N_last))

    ax.plot(fine, [amdahl(n, 0.045) for n in fine],
            "b--", linewidth=1.5, label="Amdahl (f=4.5% nominal)")
    ax.plot(fine, [amdahl(n, f_fit) for n in fine],
            "g-",  linewidth=1.5, label=f"Amdahl (f={f_fit*100:.1f}% fitted)")
    ax.plot(fine, fine, "k--", linewidth=1, alpha=0.3, label="Ideal")
    ax.plot(threads, obs, "ro-", linewidth=2, markersize=7, label="Observed")

    ax.set_xlabel("Thread count")
    ax.set_ylabel("Speedup")
    ax.set_title("Amdahl's Law – Theoretical vs Observed (Total Pipeline)")
    ax.set_xticks(threads)
    ax.legend()
    fig.tight_layout()
    path = os.path.join(out_dir, "amdahl_overlay.png")
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}")


def plot_stage_breakdown(data: dict, out_dir: str):
    """Stacked bar chart of per-stage time at each thread count."""
    threads = sorted(data.keys())
    comp_stages = ["t_gaussian", "t_sobel", "t_sharpen", "t_histogram"]

    width = 0.6
    x = np.arange(len(threads))
    fig, ax = plt.subplots(figsize=(9, 5))
    bottom = np.zeros(len(threads))

    for idx, stage in enumerate(comp_stages):
        vals = np.array([data[T][stage] for T in threads])
        ax.bar(x, vals, width, bottom=bottom, label=STAGE_LABELS[stage],
               color=COLORS[idx])
        bottom += vals

    ax.set_xticks(x)
    ax.set_xticklabels([f"T={T}" for T in threads])
    ax.set_xlabel("Thread count")
    ax.set_ylabel("Total wall time (s, summed over batch)")
    ax.set_title("Per-Stage Time Breakdown vs Thread Count")
    ax.legend(loc="upper right")
    fig.tight_layout()
    path = os.path.join(out_dir, "stage_breakdown.png")
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}")


# ── Main ─────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Generate scaling plots from benchmark CSVs")
    parser.add_argument("--results", default="results/", help="Directory containing timing CSVs")
    parser.add_argument("--out",     default="results/plots/", help="Output directory for figures")
    args = parser.parse_args()

    os.makedirs(args.out, exist_ok=True)

    data = load_timings(args.results)
    if not data:
        print(f"No timing_t*.csv files found in {args.results}")
        print("Run  make bench  first.")
        return

    threads = sorted(data.keys())
    print(f"Found data for thread counts: {threads}")
    print("Generating plots...")

    plot_speedup(data,          args.out)
    plot_efficiency(data,       args.out)
    plot_amdahl_overlay(data,   args.out)
    plot_stage_breakdown(data,  args.out)

    print(f"\nAll plots saved to: {args.out}")


if __name__ == "__main__":
    main()
